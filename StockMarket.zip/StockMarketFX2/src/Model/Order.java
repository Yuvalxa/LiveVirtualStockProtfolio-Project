package Model;

public interface Order {
	public void execute(int numOfStocks,int id);
}
