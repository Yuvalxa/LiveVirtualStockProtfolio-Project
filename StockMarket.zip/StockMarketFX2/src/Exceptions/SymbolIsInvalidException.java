package Exceptions;

public class SymbolIsInvalidException extends Exception{
	public SymbolIsInvalidException() {
		super("ERROR! Symble is Invalid");
	}
}
